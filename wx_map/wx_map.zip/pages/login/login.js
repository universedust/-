// pages/login/login.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    data: { 
      number: '', 
      password:''
      }, 
  },


  toregister() {
    wx.navigateTo({
        url: '/pages/register/register',
      })
  },


  denglu: function () {
    console.log(this.data);
    if (this.data.number == '' || this.data.number == undefined || this.data.password == '' || this.data.password == undefined) {
        wx.showModal({
            title: '系统提示',
            content: '用户名或密码不能为空！',
            showCancel: false,
            confirmText: '知道了',
            success: function (res) {
                if (res.confirm) {
                    console.log('用户点击确定')
                }
            }
        })
    } else {
        //请求登录
        var that = this;
        wx.request({
            url: 'http://81.68.216.192:8375/test archive/wx_login.do?name=' + that.data.number + '&password=' + that.data.password,
            method: 'POST',
            success: function (res) {
                console.log("===================");
                console.log(res);
                // 登录成功
                if (res.data.status == "no") {
                    var app = getApp();
                    getApp().globalData.x1 = that.data.number;
                    getApp().globalData.y1 = that.data.password;

                    wx.setStorageSync('USERNAME', that.data.name);
                       wx.showToast({
                        title: '登陆成功',
                        icon: 'success',
                        complete: function () {
                          console.log(that.data.number)
                           wx.redirectTo({
                            url: '/pages/history/history?x='+that.data.number+'&y='+that.data.password,
                            })
                        } 
                    })
                } else {
                    wx.showModal({
                        title: '系统提示',
                        content: '用户名或密码不正确！',
                        showCancel: false,
                        confirmText: '知道了',
                        success: function (res) {
                            that.setData({
                                number: '',
                                password: ''
                            })
                        }
                    })
                }
            },
            fail: function () {
                // fail
                console.log("错误")
            },
            complete: function () {
                // complete
                 console.log("complete")
            }
        })
    }
},
nameInput: function (e) {
    this.setData({
      number: e.detail.value
    })
},
passwordInput: function (e) {
    this.setData({
        password: e.detail.value
    })
},
toRes:function(){
    wx.redirectTo({
  url:"/pages/home/home"
})
}
})